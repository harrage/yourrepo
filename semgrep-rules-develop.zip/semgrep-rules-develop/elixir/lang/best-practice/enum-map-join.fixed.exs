# ruleid: enum_map_join
["a", "b", "c"]
|> Enum.map_join(", ", fn s -> String.upcase(s) end)

# ruleid: enum_map_join
["a", "b", "c"]
|> Enum.map_join(", ", fn s -> String.upcase(s) end)

# ruleid: enum_map_join
["a", "b", "c"]
|> Enum.map_join(", ", fn s -> String.upcase(s) end)
