# ruleid: deprecated_bnot_operator
~~~2

# ruleid: deprecated_bnot_operator
~~~2 &&& 3
