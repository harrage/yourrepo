# ruleid: deprecated_use_bitwise
use Bitwise
