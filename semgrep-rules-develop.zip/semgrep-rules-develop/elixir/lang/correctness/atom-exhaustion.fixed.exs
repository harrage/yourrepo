# ruleid: atom_exhaustion
String.to_existing_atom("dynamic")
# ruleid: atom_exhaustion
List.to_existing_atom(~c"dynamic")
