# ruleid: ifs-tampering
IFS=,

# ok: ifs-tampering
IFS=, read -a values
