# Security Policy

## Supported Versions

All rules on `develop` are supported.

## Reporting a Vulnerability

Please email security@semgrep.com to make a vulnerability report
