// ruleid: detect-promptfoo
import promptfoo from 'promptfoo';

// ruleid: detect-promptfoo
const results = await promptfoo.evaluate(testSuite, options);