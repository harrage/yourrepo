// ruleid: flickr-access-token
flickr_api_token = "0r7c62y5tp0hihdiumobtfzi3hkof4vr"