// ruleid: gitlab-pat
gitlab_api_token = "glpat-62o83rs98y87jyfaq5zq"
gitlab_api_token = "glptt-23d48505ab5b2a7ccc60f3d069f649040f673d44"
gitlab_api_token = "GR1348941mkiqtyh4m59oy2d9ehxb"