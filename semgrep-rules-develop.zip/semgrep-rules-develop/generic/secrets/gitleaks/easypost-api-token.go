// ruleid: easypost-api-token
EZAK_api_token = "EZAK0o7glckjdbif1gh8cy4bh9qt18l6qlvjdja722v04m96rf7y6k8i55"