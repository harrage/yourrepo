// ruleid: contentful-delivery-api-token
contentful_api_token = "4sygnpvt4aks3vd7qjxub6u1pho1i1076aw0ixohbkg"
