// ruleid: github-oauth
github_api_token = "gho_gkp19cjcgv0b0akt2skq9qhk4bswzrzagerz"
