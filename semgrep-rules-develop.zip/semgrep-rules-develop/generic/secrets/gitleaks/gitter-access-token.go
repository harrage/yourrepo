// ruleid: gitter-access-token
gitter_api_token = "_m4n272-o6i1ki3zvigmg_f25u0jrwgti_jsfaau"
