// ruleid: grafana-cloud-api-token
grafana-cloud-api-token_api_token = "glc_hw2qgpmhzndkyw4zv6p5exn0la6g8vek"
