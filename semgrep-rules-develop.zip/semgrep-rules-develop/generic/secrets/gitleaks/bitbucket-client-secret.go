// ruleid: bitbucket-client-secret
bitbucket_api_token = "hzo1035eq80q9zxtgbpthdfda0966s6xw5ur0xftzv0syjdp1etn1iprvqflxzzm"
