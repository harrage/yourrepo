// ruleid: aws-access-token
AWS_api_token = "AKIALALEMEL33243OLIB"