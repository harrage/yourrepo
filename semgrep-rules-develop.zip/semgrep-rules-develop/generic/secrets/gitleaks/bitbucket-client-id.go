// ruleid: bitbucket-client-id
bitbucket_api_token = "hain0t444gq3tytxunqbuoyu40vd7sd5"