// ruleid: flutterwave-public-key
flutterwavePubKey_api_token = "FLWPUBK_TEST-12ab053076e364bd9180f1ce3039a21f-X"
flutterwavePubKey_api_token = "FLWSECK_TEST-24e4a83d776c7a747ea932973135bc9c-X"
flutterwavePubKey_api_token = "FLWSECK_TEST-ba13077468f4"