// ruleid: gitlab-rrt
gitlab_api_token = "GR1348941mkiqtyh4m59oy2d9ehxb"