// ruleid: grafana-service-account-token
grafana-service-account-token_api_token = "glsa_cxdr7ff9h3x0v3a5tle745pt8z95mats_5b921461"
