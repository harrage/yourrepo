// ruleid: flutterwave-secret-key
flutterwavePubKey_api_token = "FLWSECK_TEST-24e4a83d776c7a747ea932973135bc9c-X"
